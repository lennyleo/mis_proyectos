
public enum Tamanio {

	GRANDE,
	CHICA,
	INDIVIDUAL;
}
