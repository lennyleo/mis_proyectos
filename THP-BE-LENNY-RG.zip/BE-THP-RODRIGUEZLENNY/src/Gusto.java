
public enum Gusto {

	MUZZARELLA, 
	FUGAZZETA,
	 NAPOLITANA, 
	JAMÓN_Y_MORRONES,
	 PROVOLONE ,
	 VERDURA;


}
